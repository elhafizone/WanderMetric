# WanderMetric logo files

- wm-mark.svg — icon-only mark, full colour (Lagoon route, Ink origin dot)
- wm-mark-onecolour.svg — single ink colour (fax, stamps, embossing, 1-colour print)
- wm-mark-reversed.svg — white route + Marigold origin on Lagoon
- wm-favicon.svg — simplified 32-grid mark on a Lagoon tile, heavier stroke; set as 16px favicon
- wm-app-icon-180.svg — apple-touch-icon (full-bleed; iOS applies the corner mask)
- wm-app-icon-512.svg — PWA / maskable icon (mark sits inside the 80% safe zone)
- wm-logo-horizontal(-onecolour|-reversed).svg — primary lockup
- wm-logo-stacked(-reversed).svg — square-ish placements (social avatars, splash)

Wordmark is live text set in Bricolage Grotesque 700. Before production, open in Figma/Illustrator and
convert text to outlines so the files render without the font.

Geometry (48-unit grid): origin dot r4.5 at (8,13); route polyline 8,13 → 16,35 → 23,21 → 30,35 → 38,13;
measurement tick 32→44 at y13. Stroke 5, round caps/joins. Clear space = height of the dot (9 units) on all sides.
Minimum sizes: mark 16px (use favicon file below 24px), horizontal lockup 96px wide.
